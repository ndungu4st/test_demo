<?php
define("ET_VERSION", '1.9.2');
define("CE_VERSION", '1.9.2');
if ( !defined('CE_AD_POSTTYPE') )
 	define('CE_AD_POSTTYPE','ad');

if ( !defined('CE_AD_CAT') )
 	define('CE_AD_CAT','ad_category');

if (!defined('CE_ET_PRICE')) define('CE_ET_PRICE', 'et_price'); //_regular_price
if (!defined('ET_FEATURED')) define('ET_FEATURED', 'et_featured'); //_regular_price