<?php
define("ET_VERSION", '2.6.6');
define("CE_VERSION", '2.6.9');
if (!defined('CE_AD_POSTTYPE')) define('CE_AD_POSTTYPE', 'product');

if (!defined('CE_AD_CAT')) define('CE_AD_CAT', 'product_cat');

if (!defined('CE_ET_PRICE')) define('CE_ET_PRICE', '_regular_price');
 //_regular_price
if (!defined('ET_FEATURED')) define('ET_FEATURED', '_et_featured');
 //_regular_price