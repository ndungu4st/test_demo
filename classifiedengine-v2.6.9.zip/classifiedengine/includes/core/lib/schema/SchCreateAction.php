<?php
class SchCreateAction extends SchAction{
	function __construct(){$this->namespace = "CreateAction";}
}