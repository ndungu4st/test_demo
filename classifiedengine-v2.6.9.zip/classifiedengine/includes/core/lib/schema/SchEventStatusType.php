<?php
class SchEventStatusType extends SchEnumeration{
	function __construct(){$this->namespace = "EventStatusType";}
}