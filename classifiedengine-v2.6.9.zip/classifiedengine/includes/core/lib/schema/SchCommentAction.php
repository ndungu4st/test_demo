<?php
class SchCommentAction extends SchCommunicateAction{
	function __construct(){$this->namespace = "CommentAction";}
}