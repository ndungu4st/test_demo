<?php
class SchMedicineSystem extends SchMedicalEnumeration{
	function __construct(){$this->namespace = "MedicineSystem";}
}