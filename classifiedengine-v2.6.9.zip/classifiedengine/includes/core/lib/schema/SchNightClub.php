<?php
class SchNightClub extends SchEntertainmentBusiness{
	function __construct(){$this->namespace = "NightClub";}
}