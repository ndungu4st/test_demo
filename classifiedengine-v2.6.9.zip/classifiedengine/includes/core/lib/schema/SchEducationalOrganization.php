<?php
class SchEducationalOrganization extends SchOrganization{
	protected $alumni	=	'Person';
	function __construct(){$this->namespace = "EducationalOrganization";}
}