<?php
class SchMedicalContraindication extends SchMedicalEntity{
	function __construct(){$this->namespace = "MedicalContraindication";}
}