<?php
class SchAutoPartsStore extends SchAutomotiveBusiness{
	function __construct(){$this->namespace = "AutoPartsStore";}
}