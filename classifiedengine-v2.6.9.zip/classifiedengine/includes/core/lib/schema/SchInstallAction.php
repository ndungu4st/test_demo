<?php
class SchInstallAction extends SchConsumeAction{
	function __construct(){$this->namespace = "InstallAction";}
}