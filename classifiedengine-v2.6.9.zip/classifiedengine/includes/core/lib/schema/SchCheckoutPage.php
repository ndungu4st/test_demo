<?php
class SchCheckoutPage extends SchWebPage{
	function __construct(){$this->namespace = "CheckoutPage";}
}