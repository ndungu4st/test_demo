<?php
class SchAdultEntertainment extends SchEntertainmentBusiness{
	function __construct(){$this->namespace = "AdultEntertainment";}
}