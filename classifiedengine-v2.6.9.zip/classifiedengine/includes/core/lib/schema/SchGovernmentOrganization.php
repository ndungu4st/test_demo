<?php
class SchGovernmentOrganization extends SchOrganization{
	function __construct(){$this->namespace = "GovernmentOrganization";}
}