<?php
class SchBrainStructure extends SchAnatomicalStructure{
	function __construct(){$this->namespace = "BrainStructure";}
}