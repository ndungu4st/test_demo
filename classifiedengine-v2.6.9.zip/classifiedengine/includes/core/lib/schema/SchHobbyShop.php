<?php
class SchHobbyShop extends SchStore{
	function __construct(){$this->namespace = "HobbyShop";}
}