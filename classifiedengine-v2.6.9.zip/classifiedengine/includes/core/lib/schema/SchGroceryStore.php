<?php
class SchGroceryStore extends SchStore{
	function __construct(){$this->namespace = "GroceryStore";}
}