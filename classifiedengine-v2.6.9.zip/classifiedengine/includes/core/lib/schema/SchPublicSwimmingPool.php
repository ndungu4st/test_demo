<?php
class SchPublicSwimmingPool extends SchSportsActivityLocation{
	function __construct(){$this->namespace = "PublicSwimmingPool";}
}