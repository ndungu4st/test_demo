<?php
class SchChildCare extends SchLocalBusiness{
	function __construct(){$this->namespace = "ChildCare";}
}