<?php
class SchBusStation extends SchCivicStructure{
	function __construct(){$this->namespace = "BusStation";}
}