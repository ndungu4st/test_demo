<?php
class SchLeaveAction extends SchInteractAction{
	protected $event	=	'Event';
	function __construct(){$this->namespace = "LeaveAction";}
}