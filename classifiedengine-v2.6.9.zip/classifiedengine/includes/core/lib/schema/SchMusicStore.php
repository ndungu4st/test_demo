<?php
class SchMusicStore extends SchStore{
	function __construct(){$this->namespace = "MusicStore";}
}