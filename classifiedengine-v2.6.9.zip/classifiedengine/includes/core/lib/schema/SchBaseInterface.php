<?php
/**
 * Project : classifiedengine
 * User: thuytien
 * Date: 10/23/2014
 * Time: 1:59 PM
 */

interface SchBaseInterface {


}