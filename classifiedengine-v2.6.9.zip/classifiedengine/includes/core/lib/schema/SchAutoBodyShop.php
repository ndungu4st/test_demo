<?php
class SchAutoBodyShop extends SchAutomotiveBusiness{
	function __construct(){$this->namespace = "AutoBodyShop";}
}