<?php
class SchPrependAction extends SchInsertAction{
	function __construct(){$this->namespace = "PrependAction";}
}