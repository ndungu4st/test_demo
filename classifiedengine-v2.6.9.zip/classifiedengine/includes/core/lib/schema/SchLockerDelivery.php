<?php
class SchLockerDelivery extends SchDeliveryMethod{
	function __construct(){$this->namespace = "LockerDelivery";}
}