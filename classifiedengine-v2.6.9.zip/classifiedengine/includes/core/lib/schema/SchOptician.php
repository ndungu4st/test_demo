<?php
class SchOptician extends SchMedicalOrganization{
	function __construct(){$this->namespace = "Optician";}
}