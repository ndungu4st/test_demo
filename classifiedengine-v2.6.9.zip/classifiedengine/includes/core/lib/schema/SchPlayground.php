<?php
class SchPlayground extends SchCivicStructure{
	function __construct(){$this->namespace = "Playground";}
}