<?php
class SchConsumeAction extends SchAction{
	function __construct(){$this->namespace = "ConsumeAction";}
}