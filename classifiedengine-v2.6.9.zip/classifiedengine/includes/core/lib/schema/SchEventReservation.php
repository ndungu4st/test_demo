<?php
class SchEventReservation extends SchReservation{
	function __construct(){$this->namespace = "EventReservation";}
}