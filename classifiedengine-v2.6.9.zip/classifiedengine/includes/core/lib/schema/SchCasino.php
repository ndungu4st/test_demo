<?php
class SchCasino extends SchEntertainmentBusiness{
	function __construct(){$this->namespace = "Casino";}
}