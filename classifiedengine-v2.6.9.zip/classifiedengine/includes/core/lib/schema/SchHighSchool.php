<?php
class SchHighSchool extends SchEducationalOrganization{
	function __construct(){$this->namespace = "HighSchool";}
}