<?php
class SchMass extends SchQuantity{
	function __construct(){$this->namespace = "Mass";}
}