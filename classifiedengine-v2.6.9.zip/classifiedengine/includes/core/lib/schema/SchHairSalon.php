<?php
class SchHairSalon extends SchHealthAndBeautyBusiness{
	function __construct(){$this->namespace = "HairSalon";}
}