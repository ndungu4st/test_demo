<?php
class SchMusicVenue extends SchCivicStructure{
	function __construct(){$this->namespace = "MusicVenue";}
}