<?php
class SchCheckInAction extends SchCommunicateAction{
	function __construct(){$this->namespace = "CheckInAction";}
}