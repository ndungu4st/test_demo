<?php
class SchOceanBodyOfWater extends SchBodyOfWater{
	function __construct(){$this->namespace = "OceanBodyOfWater";}
}