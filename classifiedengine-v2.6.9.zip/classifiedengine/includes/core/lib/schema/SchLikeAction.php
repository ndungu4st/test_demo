<?php
class SchLikeAction extends SchReactAction{

	function __construct(){$this->namespace = "LikeAction";}
}