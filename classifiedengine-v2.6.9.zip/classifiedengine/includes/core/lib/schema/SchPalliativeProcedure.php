<?php
class SchPalliativeProcedure extends SchMedicalTherapy{
	function __construct(){$this->namespace = "PalliativeProcedure";}
}