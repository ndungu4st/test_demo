<?php
class SchPhotographAction extends SchCreateAction{
	function __construct(){$this->namespace = "PhotographAction";}
}