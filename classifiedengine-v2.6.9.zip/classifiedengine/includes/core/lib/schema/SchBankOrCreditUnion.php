<?php
class SchBankOrCreditUnion extends SchFinancialService{
	function __construct(){$this->namespace = "BankOrCreditUnion";}
}