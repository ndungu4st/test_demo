<?php
class SchMedicalEnumeration extends SchEnumeration{
	function __construct(){$this->namespace = "MedicalEnumeration";}
}