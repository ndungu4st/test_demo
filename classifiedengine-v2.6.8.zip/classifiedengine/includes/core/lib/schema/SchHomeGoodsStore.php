<?php
class SchHomeGoodsStore extends SchStore{
	function __construct(){$this->namespace = "HomeGoodsStore";}
}