<?php
class SchAssignAction extends SchAllocateAction{
	function __construct(){$this->namespace = "AssignAction";}
}