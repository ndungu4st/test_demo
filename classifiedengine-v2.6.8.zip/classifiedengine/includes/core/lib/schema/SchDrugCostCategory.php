<?php
class SchDrugCostCategory extends SchEnumeration{
	function __construct(){$this->namespace = "DrugCostCategory";}
}