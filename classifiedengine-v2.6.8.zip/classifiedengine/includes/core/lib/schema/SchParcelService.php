<?php
class SchParcelService extends SchDeliveryMethod{
	function __construct(){$this->namespace = "ParcelService";}
}