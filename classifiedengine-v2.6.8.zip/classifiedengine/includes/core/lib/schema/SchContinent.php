<?php
class SchContinent extends SchLandform{
	function __construct(){$this->namespace = "Continent";}
}