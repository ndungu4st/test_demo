<?php
class SchLigament extends SchAnatomicalStructure{
	function __construct(){$this->namespace = "Ligament";}
}