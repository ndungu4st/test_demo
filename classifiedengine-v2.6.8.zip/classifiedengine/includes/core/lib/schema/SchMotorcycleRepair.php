<?php
class SchMotorcycleRepair extends SchAutomotiveBusiness{
	function __construct(){$this->namespace = "MotorcycleRepair";}
}