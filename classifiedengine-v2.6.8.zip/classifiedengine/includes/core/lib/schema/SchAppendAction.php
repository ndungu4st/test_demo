<?php
class SchAppendAction extends SchInsertAction{
	function __construct(){$this->namespace = "AppendAction";}
}