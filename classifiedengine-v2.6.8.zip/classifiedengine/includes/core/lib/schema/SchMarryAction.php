<?php
class SchMarryAction extends SchInteractAction{
	function __construct(){$this->namespace = "MarryAction";}
}