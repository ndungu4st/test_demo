<?php
class SchIceCreamShop extends SchFoodEstablishment{
	function __construct(){$this->namespace = "IceCreamShop";}
}