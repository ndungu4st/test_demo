<?php
class SchLodgingBusiness extends SchLocalBusiness{
	function __construct(){$this->namespace = "LodgingBusiness";}
}