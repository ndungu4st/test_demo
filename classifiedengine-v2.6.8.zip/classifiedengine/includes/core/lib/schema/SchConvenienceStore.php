<?php
class SchConvenienceStore extends SchStore{
	function __construct(){$this->namespace = "ConvenienceStore";}
}