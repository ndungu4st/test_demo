<?php
class SchClass extends SchIntangible{
	function __construct(){$this->namespace = "Class";}
}