<?php

class SchAgreeAction extends SchReactAction
{
    function __construct()
    {
        $this->namespace = "AgreeAction";
    }
}