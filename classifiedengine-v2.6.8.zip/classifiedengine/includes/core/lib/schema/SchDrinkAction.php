<?php
class SchDrinkAction extends SchConsumeAction{
	function __construct(){$this->namespace = "DrinkAction";}
}