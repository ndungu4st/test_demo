<?php
class SchCrematorium extends SchCivicStructure{
	function __construct(){$this->namespace = "Crematorium";}
}