<?php
class SchInviteAction extends SchCommunicateAction{
	protected $event	=	'Event';
	function __construct(){$this->namespace = "InviteAction";}
}