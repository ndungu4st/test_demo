<?php
class SchDrugPregnancyCategory extends SchEnumeration{
	function __construct(){$this->namespace = "DrugPregnancyCategory";}
}