<?php
class SchMedicalSpecialty extends SchSpecialty{
	function __construct(){$this->namespace = "MedicalSpecialty";}
}