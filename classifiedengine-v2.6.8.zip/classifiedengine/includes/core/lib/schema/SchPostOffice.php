<?php
class SchPostOffice extends SchGovernmentOffice{
	function __construct(){$this->namespace = "PostOffice";}
}