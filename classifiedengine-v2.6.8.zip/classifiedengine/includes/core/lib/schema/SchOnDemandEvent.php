<?php
class SchOnDemandEvent extends SchPublicationEvent{
	function __construct(){$this->namespace = "OnDemandEvent";}
}