<?php
class SchEventVenue extends SchCivicStructure{
	function __construct(){$this->namespace = "EventVenue";}
}