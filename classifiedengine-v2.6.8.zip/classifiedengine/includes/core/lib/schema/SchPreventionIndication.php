<?php
class SchPreventionIndication extends SchMedicalIndication{
	function __construct(){$this->namespace = "PreventionIndication";}
}