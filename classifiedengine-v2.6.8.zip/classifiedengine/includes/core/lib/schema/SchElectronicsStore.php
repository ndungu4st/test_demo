<?php
class SchElectronicsStore extends SchStore{
	function __construct(){$this->namespace = "ElectronicsStore";}
}