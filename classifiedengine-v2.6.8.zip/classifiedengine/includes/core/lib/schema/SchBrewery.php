<?php
class SchBrewery extends SchFoodEstablishment{
	function __construct(){$this->namespace = "Brewery";}
}