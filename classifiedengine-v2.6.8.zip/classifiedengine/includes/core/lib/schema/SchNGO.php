<?php
class SchNGO extends SchOrganization{
	function __construct(){$this->namespace = "NGO";}
}