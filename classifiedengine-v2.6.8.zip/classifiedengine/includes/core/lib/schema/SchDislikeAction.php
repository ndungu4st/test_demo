<?php
class SchDislikeAction extends SchReactAction{
	function __construct(){$this->namespace = "DislikeAction";}
}