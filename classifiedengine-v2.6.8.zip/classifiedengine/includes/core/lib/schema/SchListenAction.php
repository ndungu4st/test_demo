<?php

class SchListenAction extends SchConsumeAction
{
    function __construct()
    {
        $this->namespace = "ListenAction";
    }
}