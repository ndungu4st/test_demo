<?php
class SchHousePainter extends SchHomeAndConstructionBusiness{
	function __construct(){$this->namespace = "HousePainter";}
}