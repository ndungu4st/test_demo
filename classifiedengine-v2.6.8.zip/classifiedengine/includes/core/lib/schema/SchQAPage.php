<?php
class SchQAPage extends SchWebPage{
	function __construct(){$this->namespace = "QAPage";}
}