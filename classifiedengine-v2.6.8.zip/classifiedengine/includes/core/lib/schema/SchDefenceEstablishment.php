<?php
class SchDefenceEstablishment extends SchGovernmentBuilding{
	function __construct(){$this->namespace = "DefenceEstablishment";}
}