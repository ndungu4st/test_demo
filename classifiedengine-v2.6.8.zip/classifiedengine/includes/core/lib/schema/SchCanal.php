<?php
class SchCanal extends SchBodyOfWater{
	function __construct(){$this->namespace = "Canal";}
}