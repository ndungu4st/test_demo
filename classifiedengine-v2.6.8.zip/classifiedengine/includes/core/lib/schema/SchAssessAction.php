<?php
class SchAssessAction extends SchAction{
	function __construct(){$this->namespace = "AssessAction";}
}