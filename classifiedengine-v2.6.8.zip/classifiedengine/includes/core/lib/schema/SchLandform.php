<?php
class SchLandform extends SchPlace{
	function __construct(){$this->namespace = "Landform";}
}