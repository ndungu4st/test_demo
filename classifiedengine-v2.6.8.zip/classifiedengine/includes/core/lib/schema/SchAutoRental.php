<?php
class SchAutoRental extends SchAutomotiveBusiness{
	function __construct(){$this->namespace = "AutoRental";}
}