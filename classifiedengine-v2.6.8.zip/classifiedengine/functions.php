<?php
/**
 * use for generate asset link
 */
define('TEMPLATEURL', get_template_directory_uri());

// change this to 'production' when publishing the theme, to use minified scripts & styles instead
/**
 * Define invairiment state
 */
define('ENGINE_ENVIRONMENT', 'development');

/**
 * Use for check for update
 */
define("ET_UPDATE_PATH", "http://update.enginethemes.com/?do=product-update");
include_once dirname(__FILE__) . '/define/ver2.php';

if (!defined('ET_URL')) define('ET_URL', 'http://www.enginethemes.com/');

if (!defined('ET_CONTENT_DIR')) define('ET_CONTENT_DIR', WP_CONTENT_DIR . '/et-content/');

if (!defined('THEME_CONTENT_DIR ')) define('THEME_CONTENT_DIR', WP_CONTENT_DIR . '/et-content' . '/classifiedengine');
if (!defined('THEME_CONTENT_URL')) define('THEME_CONTENT_URL', content_url() . '/et-content' . '/classifiedengine');

if (!defined('THEME_LANGUAGE_PATH')) define('THEME_LANGUAGE_PATH', THEME_CONTENT_DIR . '/lang/');

/**
 * Path to language
 */
define('ET_LANGUAGE_PATH', THEME_CONTENT_DIR . '/lang/');

if (!defined('ET_CSS_PATH')) define('ET_CSS_PATH', THEME_CONTENT_DIR . '/css');

//require_once dirname(__FILE__).'/socials/fb-sdk/autoload.php';

require_once dirname(__FILE__) . '/includes/index.php';

require_once dirname(__FILE__) . '/admin/index.php';

// for mobile
require_once get_template_directory() . '/mobile/functions.php';
//google captcha class
require_once get_template_directory() . '/includes/google-captcha.php';
require_once get_template_directory() . '/includes/social_sdk.php';
require_once get_template_directory() . '/includes/ce_guide.php';
require_once get_template_directory() . '/includes/class-et-classifiedengine.php';
if (class_exists('WooCommerce')) {
    require_once get_template_directory() . '/includes/wc_integrate/WC_Integrate.php';
}

global $classified, $ce_config;

add_action('after_setup_theme', 'ce_setup_theme', 1);
function ce_setup_theme()
{
    global $classified;
    $classified = new ET_ClassifiedEngine();
}

/**
 * display list paging.
 * if not add your query, will get the global $wp_query
 *
 * @param string $query
 */
function ce_pagination($query = '')
{

    if ($query == '') {
        global $wp_query;
        $query = $wp_query;
    }

    global $ce_config;
    if ($ce_config['use_infinite_scroll'] && $query->max_num_pages > 1 && !is_category()) {
        $query_var = array();

        $query_var['post_type'] = $query->query_vars['post_type'] != '' ? $query->query_vars['post_type'] : 'post';
        $query_var['post_status'] = isset($query->query_vars['post_status']) ? $query->query_vars['post_status'] : 'publish';
        $query_var['orderby'] = isset($query->query_vars['orderby']) ? $query->query_vars['orderby'] : 'date';
        $query_var['order'] = $query->query_vars['order'];
        $query_var['action'] = 'ce-load-more-' . $query_var['post_type'];
        if (!empty($query->query_vars['meta_key'])) $query_var['meta_key'] = isset($query->query_vars['meta_key']) ? $query->query_vars['meta_key'] : 'et_featured';

        $query_var = array_merge($query_var, $query->query);

        $query_string = '';
        foreach ($query_var as $key => $value) {
            $query_string .= '&' . $key . '=' . $value;
        }

        if (isset($_REQUEST['sortby'])) {
            $query_var['sortby'] = $_REQUEST['sortby'];
        }
        ?>
        <div id="inview">
            <input type="hidden" value="<?php echo $query_string ?>" name="query_string" id="query_string"/>

            <div class="bubblingG">
                <span id="bubblingG_1"></span>
                <span id="bubblingG_2"></span>
                <span id="bubblingG_3"></span>
            </div>
            <?php
            _e('Loading more', ET_DOMAIN); ?>
            <input type="hidden" value="<?php echo $query_string?>" name="query_string" id="query_string"/>
            <script type="application/json" id="ce_query"><?php echo json_encode($query_var); ?></script>
        </div>
        <?php
        return;
    }

    $big = 999999999;

    // need an unlikely integer

    $paginate = paginate_links(array(
        'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
        'format' => '?paged=%#%',
        'current' => max(1, get_query_var('paged')),
        'total' => $query->max_num_pages,
        'type' => 'array',
        'prev_text' => '<i class="fa fa-arrow-left"></i>',
        'next_text' => '<i class="fa fa-arrow-right"></i>',
        'end_size' => 2,
        'mid_size' => 1
    ));

    if ($paginate) {
        echo ' <ul class="pagination">';
        foreach ($paginate as $key => $value) {
            echo '<li>' . $value . '</li>';
        }
        echo '</ul>';
    }
}

/**
 * Pagin in seller page
 *
 * @param $total
 * @param $current
 */
function ce_seller_pagination($total, $current)
{
    global $ce_config;
    if ($ce_config['use_infinite_scroll'] && $total > 1) {
        ?>
        <div id="inview">
            <div class="bubblingG">
                <span id="bubblingG_1">
                </span>
                <span id="bubblingG_2">
                </span>
                <span id="bubblingG_3">
                </span>
            </div>
            <?php
            _e('Loading more sellers', ET_DOMAIN); ?>
        </div>
        <?php
        return;
    }

    $big = 9999999;
    $paginate = paginate_links(array(

        //'base'        => $base, // the base URL, including query arg
        'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),

        //'format'  => $number, // this defines the query parameter that will be used, in this case
        'format' => '?paged=%#%',
        'prev_text' => '<i class="fa fa-arrow-left"></i>',
        'next_text' => '<i class="fa fa-arrow-right"></i>',
        'total' => $total,

        // the total number of pages we have
        'current' => $current,

        // the current page
        'end_size' => 1,
        'mid_size' => 3,
        'type' => 'array',
    ));

    if (is_array($paginate)) {
        echo ' <ul class="pagination">';
        foreach ($paginate as $key => $value) {
            echo '<li>' . $value . '</li>';
        }
        echo '</ul>';
    }
}

/**
 * Pagin in review page
 *
 * @param $total
 */
function ce_review_pagination($total)
{

    global $ce_config;

    $current = 1;
    if (get_query_var('paged')) $current = get_query_var('paged');

    if ($ce_config['use_infinite_scroll'] && $total > 1) {
        global $wp_query;
        $query_var = array();

        $query_var['reviews'] = $wp_query->query_vars['review'];
        $query_var['author'] = $wp_query->query_vars['author_name'];
        $query_var['action'] = 'ce-load-more-reviews';
        $query_string = '';
        foreach ($query_var as $key => $value) {
            $query_string .= '&' . $key . '=' . $value;
        }
        ?>
        <div id="review-inview">
            <div class="bubblingG">
                <span id="bubblingG_1">
                </span>
                <span id="bubblingG_2">
                </span>
                <span id="bubblingG_3">
                </span>
            </div>
            <?php
            _e('Loading more reviews', ET_DOMAIN); ?>
        </div>
        <input type="hidden" value="<?php
        echo $query_string
        ?>" name="query_string" id="query_string"/>
        <script type="application/json" id="reviews_query"><?php
            echo json_encode($query_var); ?></script>
        <?php
        return;
    }

    $big = 9999999;
    $paginate = paginate_links(array(

        //'base'        => $base, // the base URL, including query arg
        'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),

        //'format'  => $number, // this defines the query parameter that will be used, in this case
        'format' => '?paged=%#%',
        'prev_text' => '<i class="fa fa-arrow-left"></i>',
        'next_text' => '<i class="fa fa-arrow-right"></i>',
        'total' => $total,

        // the total number of pages we have
        'current' => $current,

        // the current page
        'end_size' => 1,
        'mid_size' => 3,
        'type' => 'array',
    ));

    if (is_array($paginate)) {
        echo ' <ul class="pagination">';
        foreach ($paginate as $key => $value) {
            echo '<li>' . $value . '</li>';
        }
        echo '</ul>';
    }
}

/**
 * Return format text with a number
 * @since 1.0
 * @param $zero
 * zero format
 * @param $single
 * single format
 * @param $plural
 * plural format
 * @param $number
 * input number
 */
function et_number($zero, $single, $plural, $number)
{
    if ($number == 0) return $zero;
    elseif ($number == 1) return $single;
    else return $plural;
}



/**
 * Send mesage if user using cash payment
 *
 * @param $cash_message
 */
function ce_send_cash_message($cash_message)
{
    // $auto_email = et_get_auto_emails();
    $session = et_read_session();
    $ad_id = '';
    if ($session['ad_id']) $ad_id = $session['ad_id'];
    CE_Mailing::send_cash_message($cash_message, $ad_id);
}
// add_action('et_cash_checkout', 'ce_send_cash_message');


if (!function_exists('ae_check_ajax_referer')):

    /**
     * Verifies the AJAX request to prevent processing requests external of the blog.
     *
     * @since 2.0.3
     *
     * @param string $action Action nonce
     * @param string $query_arg where to look for nonce in $_REQUEST (since 2.5)
     */
    function ae_check_ajax_referer($action = -1, $query_arg = false, $die = true)
    {
        $nonce = '';

        if ($query_arg && isset($_REQUEST[$query_arg])) $nonce = $_REQUEST[$query_arg];
        elseif (isset($_REQUEST['_ajax_nonce'])) $nonce = $_REQUEST['_ajax_nonce'];
        elseif (isset($_REQUEST['_wpnonce'])) $nonce = $_REQUEST['_wpnonce'];

        $result = ae_verify_nonce($nonce, $action);

        if ($die && false == $result) {
            if (defined('DOING_AJAX') && DOING_AJAX) wp_die(-1);
            else die('-1');
        }

        /**
         * Fires once the AJAX request has been validated or not.
         *
         * @since 2.1.0
         *
         * @param string $action The AJAX nonce action.
         * @param bool $result Whether the AJAX request nonce was validated.
         */
        do_action('check_ajax_referer', $action, $result);

        return $result;
    }
endif;

if (!function_exists('ae_verify_nonce')):

    /**
     * Verify that correct nonce was used with time limit.
     *
     * The user is given an amount of time to use the token, so therefore, since the
     * UID and $action remain the same, the independent variable is the time.
     *
     * @since 2.0.3
     *
     * @param string $nonce Nonce that was used in the form to verify
     * @param string|int $action Should give context to what is taking place and be the same when nonce was created.
     * @return bool Whether the nonce check passed or failed.
     */
    function ae_verify_nonce($nonce, $action = -1)
    {
        $user = wp_get_current_user();
        $uid = (int)$user->ID;
        if (!$uid) {

            /**
             * Filter whether the user who generated the nonce is logged out.
             *
             * @since 3.5.0
             *
             * @param int $uid ID of the nonce-owning user.
             * @param string $action The nonce action.
             */
            $uid = apply_filters('nonce_user_logged_out', $uid, $action);
        }

        $i = wp_nonce_tick();

        // Nonce generated 0-12 hours ago
        if (substr(wp_hash($i . $action . $uid, 'nonce'), -12, 10) === $nonce) return 1;

        // Nonce generated 12-24 hours ago
        if (substr(wp_hash(($i - 1) . $action . $uid, 'nonce'), -12, 10) === $nonce) return 2;
        return false;
    }
endif;

if (!function_exists('ae_create_nonce')):

    /**
     * Creates a random, one time use token.
     *
     * @since 2.0.3
     *
     * @param string|int $action Scalar value to add context to the nonce.
     * @return string The one use form token
     */
    function ae_create_nonce($action = -1)
    {
        $user = wp_get_current_user();
        $uid = (int)$user->ID;
        if (!$uid) {

            /** This filter is documented in wp-includes/pluggable.php */
            $uid = apply_filters('nonce_user_logged_out', $uid, $action);
        }

        $i = wp_nonce_tick();

        return substr(wp_hash($i . $action . $uid, 'nonce'), -12, 10);
    }
endif;

/**
 * Notices when update to version 2.3
 */
 function notice_update_version() {
    $ce_options = new CE_Options;
    $update_version = $ce_options->get_option('et_update_role');
    $dismiss_notice = $ce_options->get_option('dismiss_notice');
    if(!$update_version && CE_AD_POSTTYPE == 'product'){
        $class = "error update";
        $message = __("PLEASE UPDATE YOUR DATABASE, <a href='admin.php?page=et-wizard'>CLICK HERE</a> TO UPDATE", ET_DOMAIN);
        echo"<div class=\"$class\"> <p style='color:#f00'><strong>$message</strong></p></div>";
    }elseif($update_version && CE_AD_POSTTYPE == 'product' && !$dismiss_notice){
        $class = "updated notice is-dismissible dismiss_notice";
        $message = __("YOUR DATABASE HAS BEEN UPDATED.",ET_DOMAIN);
        $url = add_query_arg('dismiss-notice','true');
        echo"<div class=\"$class\"> <p class='text-success'><strong>$message</strong> <a href=\"$url\" class='btn-info btn'>Dismiss</a></p> </div>";
    }
}
add_action( 'admin_notices', 'notice_update_version' );

/**
 * fucntion will dismiss notice when update database sucess
 * @author Quang Đạt
 */
function abort_notice(){
    $request = $_REQUEST;
    if(isset($request['dismiss-notice']) && $request['dismiss-notice'] == 'true'){
        $ce_options = new CE_Options;
        $ce_options->update_option('dismiss_notice', $request['dismiss-notice']);
    }
}
add_action('admin_init','abort_notice');

function review_form($comment){
   $commenter = wp_get_current_commenter();
   $title = "<div class='btn_review'>".__('write your review', ET_DOMAIN)."</div>";

    $comment_form = array(
        'title_reply'          => $title,
        'title_reply_to'       => __( 'Leave a Reply to %s', ET_DOMAIN ),
        'comment_notes_before' => '',
        'comment_notes_after'  => '',
        'fields'               => array(
            'author' => '<p class="comment-form-author">' . '<label for="author">' . __( 'Name', ET_DOMAIN ) . ' <span class="required">*</span></label> ' .
                        '<input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30" aria-required="true" /></p>',
            'email'  => '<p class="comment-form-email"><label for="email">' . __( 'Email', ET_DOMAIN ) . ' <span class="required">*</span></label> ' .
                        '<input id="email" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" size="30" aria-required="true" /></p>',
        ),
        'label_submit'  => __( 'Submit', ET_DOMAIN ),
        'logged_in_as'  => '',
        'comment_field' => ''
    );

    if ( get_option( 'woocommerce_enable_review_rating' ) === 'yes' ) {
        $comment_form['comment_field'] = '<p class="comment-form-rating"><label for="rating">' . __( 'Your Rating', ET_DOMAIN ) .'</label><select name="rating" id="rating">
            <option value="">' . __( 'Rate&hellip;', ET_DOMAIN ) . '</option>
            <option value="5">' . __( 'Perfect', ET_DOMAIN ) . '</option>
            <option value="4">' . __( 'Good', ET_DOMAIN ) . '</option>
            <option value="3">' . __( 'Average', ET_DOMAIN ) . '</option>
            <option value="2">' . __( 'Not that bad', ET_DOMAIN ) . '</option>
            <option value="1">' . __( 'Very Poor', ET_DOMAIN ) . '</option>
        </select></p>';
    }

                    $comment_form['comment_field'] .= '<p class="comment-form-comment"><label for="comment">' . __( 'Your Review', ET_DOMAIN ) . '</label><textarea id="comment" name="comment" cols="45" rows="8" aria-required="true"></textarea></p>';
    return $comment_form;

}
add_filter('woocommerce_product_review_comment_form_args','review_form',10,1);

if (  class_exists( 'WooCommerce' ) ) {
    function process_review($commentdata){
        global $user_ID, $current_user;
        $post = get_post($commentdata['comment_post_ID']);

        if ( is_user_logged_in() ) {
            $email = $current_user->user_email;
        } else {
            $email = $commentdata['comment_author_email'];
        }
        $args = array(
            'author_email' =>$email,
            'post_id'=>$commentdata['comment_post_ID'],
            'comment_type'=>'review',
            );
        $user_comments = get_comments($args);
        $flag = 0;
        if(!empty($user_comments)){
            wp_die(__("You have already reviewed this seller about this classified.", ET_DOMAIN));
        } else {
            return $commentdata;
        }
    }
    add_action('preprocess_comment', 'process_review',12,1);
}


   /**
     * hook to filter comment type dropdown and add review favorite to filter comment
     * @param Array $comment_types
     * @return Array result $comment_types
     * @since 2.7
     */
function admin_comment_types_dropdown($comment_types){
    $comment_types['report']   = __("Report", ET_DOMAIN);
    return $comment_types;
}
add_filter('admin_comment_types_dropdown','admin_comment_types_dropdown');


function confirm_mail($mail_content){
     $e = new ET_CEMailTemplate();
    $email = $e->get_register_mail();
    //$reginter = $email->get_register_mail();
    $mail_content = $email.$mail_content;
    return $mail_content;
}
add_filter('confirm_email','confirm_mail');